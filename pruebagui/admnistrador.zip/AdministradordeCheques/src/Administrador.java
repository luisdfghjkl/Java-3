import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.WindowConstants;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;


public class Administrador extends JFrame {
	
	public static void main (String [] args) {

		
/////////////////////////Clientes Bancopek
	CuentadeCheques c0= new CuentadeCheques(1);
	CuentaHabiente h1= new CuentaHabiente (11,"Juan");
	
	Map<CuentadeCheques,CuentaHabiente> c1 = new HashMap<CuentadeCheques,CuentaHabiente> ();
	
	c1.put(c0, h1);
	
	for (Entry<CuentadeCheques,CuentaHabiente> jugador : c1.entrySet()){
		CuentadeCheques clave = jugador.getKey();
		CuentaHabiente valor = jugador.getValue();
		System.out.println(clave.toString()+"  ->  "+valor.toString());
	}
	
	
	 ArrayList Bancopel =new ArrayList();
	 Bancopel.add(c1);
	 System.out.println("Lista: "+Bancopel);
///////////////////////////////////////////////////////////////////
	 
////////////////////////////////////Clientes BBVA
	 	
	 
	 	CuentadeCheques c2= new CuentadeCheques(1);
		CuentaHabiente h2= new CuentaHabiente (11,"Juan");
		
		Map<CuentadeCheques,CuentaHabiente> cl2 = new HashMap<CuentadeCheques,CuentaHabiente> ();
		
		cl2.put(c2, h2);
		
		for (Entry<CuentadeCheques,CuentaHabiente> cliente : c1.entrySet()){
			CuentadeCheques clave = cliente.getKey();
			CuentaHabiente valor = cliente.getValue();
			System.out.println(clave.toString()+"  ->  "+valor.toString());
		}
	 
	 
	 
	 ArrayList BBVA = new ArrayList ();
	 BBVA.add(cl2);
	 System.out.println("Lista: "+BBVA);
	 
	 
	 
	 
	 
////////////////////////////////////////////////////////////////////////////////////////////	 
	 ArrayList Chafamex = new ArrayList ();
	  
	 //Construccion del arbol
	 
	 DefaultMutableTreeNode Bancos = new DefaultMutableTreeNode ("Bancos");
	 DefaultTreeModel modelo = new DefaultTreeModel (Bancos);
	 JTree tree = new JTree (modelo);
	
	 //Construccion de los datos del arbol 
	 
	 DefaultMutableTreeNode Banco1 = new DefaultMutableTreeNode ("Bancopel");
	 
	 
	 DefaultMutableTreeNode Banco2 = new DefaultMutableTreeNode ("BBVA");
	 modelo.insertNodeInto(Banco1, Bancos, 0);
	 modelo.insertNodeInto(Banco2, Bancos, 0);
	 
	 DefaultMutableTreeNode cliente1= new DefaultMutableTreeNode (c1);
	 modelo.insertNodeInto(cliente1, Banco1, 0);
	 DefaultMutableTreeNode cliente2= new DefaultMutableTreeNode (cl2);
	 modelo.insertNodeInto(cliente2, Banco2, 0);
	 //Botones
	
	initComponents(tree);
	
	
	
	}
	
	public static void initComponents(JTree tree ){
		
		//Construccion y visualizacion del la ventana
		 JFrame v = new JFrame("Administrador de cuentas");
		 v.setSize(850,500);
		 v.setMinimumSize(new Dimension(850,500));
		 JPanel izq= new JPanel ();
		 JPanel centro = new JPanel ();
		 JPanel der= new JPanel ();
		 JList cuentas= new JList();
		 
		 
		 
	     JScrollPane scroll = new JScrollPane(tree);
	     scroll.setBounds(200, 100, 310, 375);
	    // scroll.setLayout(null);
	     centro.add(cuentas);
	     
	     
	    
	     izq.add(scroll);
	  
	    
	     
	    // v.getContentPane().add(scroll);
	  
	   //  v.getContentPane().add(Consultar);
	    // v.setSize(850,500);
	     v.pack();
	     
		 JButton Consultar,Depositar,Retirar,Salir;
		 
		 Consultar = new JButton ("Consultar");
		 Consultar.setBounds(80, 680 , 135, 47);
		 Depositar = new JButton ("Depositar");
		 Retirar = new JButton ("Retirar");
		 Salir = new JButton ("Salir");
		 der.add(Consultar);
		 der.add(Depositar);
		 der.add(Retirar);
		 der.add(Salir);
		 
		 JLabel l1= new JLabel ();
		 l1.setText("Bancos");
		 l1.setBounds(0,0,50,100);
		 izq.add(l1);
		
		 v.add(izq,BorderLayout.WEST);
	     v.add(centro,BorderLayout.CENTER);
	     v.add(der, BorderLayout.EAST);
	     v.setVisible(true);
	     v.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
}