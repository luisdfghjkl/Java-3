

public class CuentadeCheques {

	int NumeroDeCuenta;
	int Saldo;
	
	public CuentadeCheques(int Num) {
        this.NumeroDeCuenta = Num;
    }
	 public String toString() {
	        return "Numero de cuenta:"+NumeroDeCuenta;
	                //To change body of generated methods, choose Tools | Templates.
	    }
	
	
}
