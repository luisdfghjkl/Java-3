import CuentadeCheques;


public class Banco   {
	   int numero_cuenta;
	    double saldo;
	    
	    public Banco(){
	        numero_cuenta=1;
	        saldo=0;
	    }
	    
	    public CuentadeCheques(String nombre){
	        //podemos ejecutar el constructor de la clase padre
	         //de forma explicita (por default se ejecuta el
	         //constructor sin parametros)  
	         super(nombre);
	        //super se refiere a la clase padre
	        //La ejecucion del constructor de clase padre, debe ser
	        //siempre la primera linea del constructor
	        //cedula="xxxxx";
	         //experiencia=20;
	         //this.nombre=nombre;
	    }
	    public CuentadeCheques(String nombre,int numero_cuenta,double saldo){
	        //ejecutamos un constructor ya existene en esta clase.
	        //debe ser la primera linea de codigo del construcor

	    	
	        this(nombre);
	        this.numero_cuenta=numero_cuenta;
	        this.saldo= saldo;
	        
	        
	    }
	    

	    public double getSaldo() {
	        return saldo;
	    }

	    public void setSaldo(double saldo) throws SaldoIncorrecto{
	    	if(saldo < 0) {
	    		throw new SaldoIncorrecto();
	    	}
	        this.saldo = saldo;
	    }

	    public int getNumero_Cuenta() {
	        return numero_cuenta;
	    }

	    public void setNumero_Cuenta(int numero_cuenta) {
	        this.numero_cuenta = numero_cuenta;
	    }
	    
	    public void Transferencia (double dinero,CuentadeCheques destino ) throws SaldoNegativo {
	    	
	    	if (saldo< dinero) {
	    		throw new SaldoNegativo();
	    	}
	    	saldo= saldo- dinero;
	    	destino.Deposito(dinero);
	    
	    	
	    	
	    }
	    
	    public double Retiro (double cantidadDecrementa )throws SaldoNegativo {
	    	if (saldo< cantidadDecrementa) {
	    		throw new SaldoNegativo();
	    	}
	    	 this.saldo =saldo - cantidadDecrementa;
	    	 return saldo;
	    }
	    
	   public double Deposito (double dinero) throws SaldoNegativo{
		   if (dinero < 0) {
			   throw new SaldoNegativo();
		   }
		   this.saldo =saldo +dinero;
		   return saldo;
		   
	   }    
	 
	   
	  
	    @Override
	    public String toString() {
	    	
	    	return "Soy : "+nombre+" mi numero de cuenta es  "+numero_cuenta+"mi saldo es: "+ saldo+" pesos.";
	    	
	    }
	}
	
}
