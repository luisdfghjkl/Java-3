
public class SaldoNegativo extends Exception {

	public SaldoNegativo () {
		
		super ("Saldo insuficiente para realizar esta transaccion ");
	}
}
